#include "stm32f10x_it.h" 
#include "Upstandingcar.h"
#include "Motor.h"
#include "Key.h"
#include "usart.h"
#include "math.h"
#include "MPU6050.h"
#include "String.h"
#include "Steering_Engine.h"
#include "LED.h"

#define Pi 3.1415926535

u8  Fangbo_Time = 0;
u8  Zhengxianbo_Time = 0;
u8  Juchibo_Time = 0;
u8  Sanjiaobo_Time = 0;
u16 AIMYAW_Time = 0;
u8  len;
u8  t;
u8  Actual_Line = 0;
u8  Temp[3] = {0};
s8  string[30] = {0};
u16 Steering_Engine1_Pulse = 1480;
u16 Steering_Engine2_Pulse = 1480;
u8  CMD_BIT = 1;
u8  Reset_Bit = 0;
s16 S1 = 0;
s16 S2 = 0;
s16 S3 = 0;
s16 S4 = 0;
s16 S5 = 0;
s16 S6 = 0;
s16 HY = 2048;
s16 HX = 2048;

void System_Reset(void) {
	__set_FAULTMASK(1); 
	NVIC_SystemReset(); 
}

void NMI_Handler(void)
{
}
 
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}
 
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

 
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}
 
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}
 
void SVC_Handler(void)
{
}
 
void DebugMon_Handler(void)
{
}
 
void PendSV_Handler(void)
{
}
 
void SysTick_Handler(void)
{
	BST_u8SpeedControlCount++;			                             //С���ٶȿ��Ƶ��ü���ֵ
	Key_Test_Count++;                                            //�������ü���ֵ
	
	GetMotorPulse();                                             //��ȡ���ת��
	MPU6050_Pose();                                              //��ȡλ����Ϣ
	
	if(USART_RX_STA_UART4&0x8000){
		S1 = ((USART_RX_BUF_UART4[0]<<8)|USART_RX_BUF_UART4[1]);    
		S2 = ((USART_RX_BUF_UART4[2]<<8)|USART_RX_BUF_UART4[3]);
		S3 = ((USART_RX_BUF_UART4[4]<<8)|USART_RX_BUF_UART4[5]);
		S4 = ((USART_RX_BUF_UART4[6]<<8)|USART_RX_BUF_UART4[7]);
		S5 = ((USART_RX_BUF_UART4[8]<<8)|USART_RX_BUF_UART4[9]);
		S6 = ((USART_RX_BUF_UART4[10]<<8)|USART_RX_BUF_UART4[11]);
		HY = ((USART_RX_BUF_UART4[12]<<8)|USART_RX_BUF_UART4[13]);
		HX = ((USART_RX_BUF_UART4[14]<<8)|USART_RX_BUF_UART4[15]);
		USART_RX_STA_UART4 = 0;
	}
	
	CMD_BIT = S4%2;
	Reset_Bit = S6%2;
	
	if(CMD_BIT){
		if(HY < 1000){
			Carrun_Speed = 80;
		}
		else if(HY > 3000){
			Carrun_Speed = -80;
		}
		else{
			Carrun_Speed = 0;
		}
		
		if(HX < 1000){
			Carturn_Speed = 45;
		}
		else if(HX > 3000){
			Carturn_Speed = -45;
		}
		else{
			Carturn_Speed = 0;
		}
		AngleControl();
	}
	
	if(USART_RX_STA&0x8000)
		{					   
			len=USART_RX_STA&0x3fff;//�õ��˴ν��յ������ݳ���
			if(len == 3){
				Actual_Line = ((USART_RX_BUF[0]&0X0F)*100+(USART_RX_BUF[1]&0X0F)*10+(USART_RX_BUF[2]&0X0F));
			}
			if(len == 2){
				Actual_Line = ((USART_RX_BUF[0]&0X0F)*10+(USART_RX_BUF[1]&0X0F));
			}
			if(len == 1){
				Actual_Line = (USART_RX_BUF[0]&0X0F);
			}
			USART_RX_STA=0;
		}
	
	if(Key_Test_Count>=2){
		Key_Proc();
		Key_Test_Count = 0;
	}
	if(BST_u8SpeedControlCount>=8)       //������ֵ8ʱ������ϵͳ����40msʱ��(ÿ10���Ƕ�PWM���������1���ٶ�PWM����������ܱ����ٶ�PID��������ŽǶ�PID������Ӷ�Ӱ��С��ƽ��)
	{
		if(!CMD_BIT){
			BST_fRollControlOut = 0;
		}
		else{
			RollControl();
		}
		EngineOutput();
		
		S32LeftSpeedDisp = BST_s32LeftMotorPulseSigma;
		S32RightSpeedDisp = BST_s32RightMotorPulseSigma;
		
		if(!CMD_BIT){
			BST_fSpeedLeftControlOutNew = BST_fSpeedRightControlOutNew = 0;
		}
		else{
			SpeedControl();//��ģ�ٶȿ��ƺ���   ÿ40ms����һ��
		}
		MotorOutput();					  //С����PWM���
		
		USART1_printf(USART1,"HX:%d,HY:%d\r\n",(int)BST_fCarSpeedLeft,(int)BST_fCarSpeedRight);
		 
		BST_u8SpeedControlCount=0;		                                                           //С���ٶȿ��Ƶ��ü���ֵ����
	}
}


