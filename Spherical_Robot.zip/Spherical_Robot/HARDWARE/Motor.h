#ifndef __MOTOR_H
#define __MOTOR_H
#include "sys.h"

extern unsigned int Motor_Left_Speed,Motor_Right_Speed;

void Motor_Init(u16 arr,u16 psc);
void Motor_Control(unsigned char Motor_Left_Dir,unsigned int Motor_Left_Speed,unsigned char Motor_Right_Dir,unsigned int Motor_Right_Speed);

#endif
