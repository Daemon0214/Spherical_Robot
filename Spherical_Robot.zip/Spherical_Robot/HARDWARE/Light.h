#ifndef __LIGHT_H
#define __LIGHT_H	 
#include "sys.h"

void Light_Init(void);

#endif

