#ifndef __STEERING_ENGINE_H_
#define __STEERING_ENGINE_H_
#include "sys.h"


void Steering_Engine1_Init(void);
void Steering_Engine2_Init(void);
void Steering_Engine1_forward(unsigned int pulse);
void Steering_Engine2_forward(unsigned int pulse);



#endif

