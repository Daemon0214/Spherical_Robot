#ifndef __ENCODER_H
#define __ENCODER_H
#include "sys.h"
#include "stm32f10x.h"
#include "stm32f10x_exti.h"

void TIM2_Encoder_Init(void);
void TIM3_Encoder_Init(void);
void TIM2_External_Clock_CountingMode(void);
void TIM3_External_Clock_CountingMode(void);

extern int leftcount;      
extern int rightcount;

#endif

