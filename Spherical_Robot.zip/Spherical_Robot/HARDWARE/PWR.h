#ifndef __PWR_H
#define __PWR_H

#include "sys.h"

#define PWR_5V0_2_CTL PBout(12)	// PA8
#define PWR_3V3_2_CTL PBout(13)	// PD2
#define PWR_6V0_1_CTL PBout(14)	// PA8
#define PWR_6V0_2_CTL PBout(15)	// PD2
#define PWR_12V0_CTL PBout(1)	// PA8
#define VCC_CAM_EN PAout(11)	// PD2
#define VCC_MOT_EN PAout(12)	// PA8

void PWR_Init(void);//��ʼ��

#endif

