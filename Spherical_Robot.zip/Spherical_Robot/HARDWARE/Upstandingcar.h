#ifndef __UPSTANDINGCAR_H
#define __UPSTANDINGCAR_H
#include "sys.h"
#include "MPU6050.h"
#include "stm32f10x_it.h" 
#include "Steering_Engine.h"

#define CAR_POSITION_MAX	3000       //8000
#define CAR_POSITION_MIN	(-3000)     //-8000

#define    CAR_ZERO_ANGLE (0)		 

extern float BST_fCarAngle;
extern float  BST_fAngleControlOut;

extern s32 CAR_POSITION_SET;
extern s16 CAR_SPEED_SET;

extern s16 BST_s16LeftMotorPulse,BST_s16RightMotorPulse;
extern float BST_fLeftMotorOut,BST_fRightMotorOut,BST_fPS2DirectionNew;
extern float BST_fSpeedControlOutNew;
extern unsigned int Left_Motor_Pulse;
extern unsigned int Right_Motor_Pulse;
extern float BST_fCarSpeed_PL,BST_fCarSpeed_IL,BST_fCarSpeed_DL,BST_fCarSpeed_PR,BST_fCarSpeed_IR,BST_fCarSpeed_DR,BST_fCarAngle_P,BST_fCarAngle_D;
extern u8 BST_u8SpeedControlCount;
extern s32 BST_s32LeftMotorPulseSigma,BST_s32RightMotorPulseSigma;
extern s32 S32LeftSpeedDisp,S32RightSpeedDisp;
extern float Aim_Yaw;
extern float BST_fCarYaw_P,BST_fCarYaw_D;
extern float BST_fYawControlOut;
extern float BST_fCarDir_P;
extern float BST_fCarDir_D;
extern s16 Error_Line;
extern float BST_fCarRoll;
extern float BST_fRollControlOut;
extern float BST_fCarRoll_P;
extern float BST_fCarRoll_D;
extern float BST_fSpeedLeftControlOutNew;
extern float BST_fSpeedRightControlOutNew;
extern float Carrun_Speed;
extern float Carturn_Speed;
extern float BST_fCarSpeedLeft;
extern float BST_fCarSpeedRight;


void CarUpstandInit(void);
void SetMotorVoltageAndDirection(s32 s32LeftVoltage,s32 s32RightVoltage);
void MotorOutput(void);
void EngineOutput(void);
void GetMotorPulse(void);
void SpeedControl(void);
void AngleControl(void);
void YawControl(void);
void DirControl(void);
void RollControl(void);


#endif
